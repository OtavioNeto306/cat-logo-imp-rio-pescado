import { useState, useMemo, useEffect } from 'react';
import { initialProducts, initialCategories } from '../data/products';
import { Product, Category } from '../types';

const PRODUCTS_STORAGE_KEY = 'imperio_pescado_products';
const CATEGORIES_STORAGE_KEY = 'imperio_pescado_categories';

const generateSlug = (name: string): string => {
  if (!name) return '';
  return name
      .toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // Remove accents
      .replace(/[^a-z0-9\s-]/g, '') // Remove special chars
      .trim()
      .replace(/\s+/g, '-') // Replace spaces with -
      .replace(/-+/g, '-'); // Replace multiple - with single -
};

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    let loadedProducts: Product[] = [];
    try {
      const storedProducts = window.localStorage.getItem(PRODUCTS_STORAGE_KEY);
      if (storedProducts) {
        loadedProducts = JSON.parse(storedProducts);
      }
    } catch (error) {
      console.error("Failed to parse products from localStorage", error);
    }

    // Ensure all loaded products have an 'isActive' boolean property.
    // If no products were loaded from localStorage, use initialProducts.
    const productsToInitialize = loadedProducts.length > 0 ? loadedProducts : initialProducts;

    const productsWithDefaults = productsToInitialize.map(p => ({
      ...p,
      isActive: p.isActive === undefined ? true : p.isActive, // Default to true if undefined or null
    }));

    // If initialProducts were used (meaning localStorage was empty or invalid),
    // save them immediately to localStorage with isActive defaults.
    if (loadedProducts.length === 0 && initialProducts.length > 0) {
        window.localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(productsWithDefaults));
    }
    
    return productsWithDefaults;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const storedCategories = window.localStorage.getItem(CATEGORIES_STORAGE_KEY);
      if (storedCategories) {
        return JSON.parse(storedCategories);
      }
    } catch (error) {
      console.error("Failed to parse categories from localStorage", error);
    }
    window.localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(initialCategories));
    return initialCategories;
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Persist products to localStorage whenever they change
  useEffect(() => {
    try {
      window.localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
    } catch (error) {
      console.error("Failed to save products to localStorage", error);
    }
  }, [products]);

  // Persist categories to localStorage whenever they change
  useEffect(() => {
    try {
        window.localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(categories));
    } catch (error) {
        console.error("Failed to save categories to localStorage", error);
    }
  }, [categories]);

  const filteredProducts = useMemo(() => {
    let filtered: Product[] = [...products];

    // Only show active products on the public-facing catalog
    filtered = filtered.filter(p => p.isActive); 

    if (selectedCategory) {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    if (searchTerm) {
      const lowercasedFilter = searchTerm.toLowerCase();
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(lowercasedFilter) ||
        product.code.toLowerCase().includes(lowercasedFilter) ||
        product.description.toLowerCase().includes(lowercasedFilter)
      );
    }
    
    return filtered;
  }, [products, searchTerm, selectedCategory]);

  // Use this for admin panel, where all products (active or not) should be visible
  const allProductsIncludingInactive = useMemo(() => products, [products]);

  const getProductByCode = (code: string): Product | undefined => {
    // This should search through all products, not just active ones, for admin purposes potentially
    // For consistency with ProductDetailPage which checks isActive explicitly, this is fine
    return products.find(p => p.code === code);
  };
  
  const getCategoryBySlug = (slug: string): Category | undefined => {
      return categories.find(c => c.slug === slug);
  };
  
  const addProduct = (product: Product) => {
    setProducts(prevProducts => [...prevProducts, { ...product, isActive: product.isActive === undefined ? true : product.isActive }]); // Ensure new products respect isActive or default to true
  };

  const updateProduct = (updatedProduct: Product) => {
    setProducts(prevProducts => 
      prevProducts.map(p => (p.code === updatedProduct.code ? updatedProduct : p))
    );
  };

  const deleteProduct = (code: string) => {
    setProducts(prevProducts => prevProducts.filter(p => p.code !== code));
  };

  const addCategory = (category: Omit<Category, 'slug'>): boolean => {
    const slug = generateSlug(category.name);

    if (categories.some(c => c.slug === slug)) {
        alert('Erro: Uma categoria com nome similar (mesmo slug) já existe.');
        return false;
    }

    const newCategory: Category = { ...category, slug };
    setCategories(prev => [...prev, newCategory]);
    return true;
  };

  const updateCategory = (slugToUpdate: string, data: { name: string; imageUrl: string }): boolean => {
    const newSlug = generateSlug(data.name);
    
    // Check if the new name/slug would conflict with another existing category
    if (newSlug !== slugToUpdate && categories.some(c => c.slug === newSlug)) {
      alert('Erro: Já existe uma categoria com um nome similar (mesmo slug).');
      return false;
    }

    // Update the category itself
    setCategories(prevCategories => 
      prevCategories.map(cat => 
        cat.slug === slugToUpdate 
          ? { ...cat, name: data.name, imageUrl: data.imageUrl, slug: newSlug } 
          : cat
      )
    );

    // If the slug changed, update all associated products
    if (slugToUpdate !== newSlug) {
      setProducts(prevProducts =>
        prevProducts.map(p => 
          p.category === slugToUpdate ? { ...p, category: newSlug } : p
        )
      );
    }
    
    return true;
  };

  const deleteCategory = (slug: string): boolean => {
    if (products.some(p => p.category === slug)) {
      alert('Não é possível excluir esta categoria, pois existem produtos associados a ela.');
      return false;
    }

    if (window.confirm('Tem certeza que deseja excluir esta categoria? A ação não pode ser desfeita.')) {
      setCategories(prevCategories => prevCategories.filter(cat => cat.slug !== slug));
      return true;
    }
    return false;
  };


  return {
    products: filteredProducts, // This is for public facing view (only active products)
    allProducts: allProductsIncludingInactive, // This is for admin view (all products, active or not)
    categories,
    searchTerm,
    setSearchTerm,
    selectedCategory,
    setSelectedCategory,
    getProductByCode,
    getCategoryBySlug,
    addProduct,
    updateProduct,
    deleteProduct,
    addCategory,
    updateCategory,
    deleteCategory,
  };
};